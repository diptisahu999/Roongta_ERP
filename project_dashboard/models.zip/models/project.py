# -*- coding: utf-8 -*-
from odoo import models, api, _
from odoo.exceptions import ValidationError

class Project(models.Model):
    _inherit = 'project.project'

    @api.constrains('stage_id')
    def _check_all_tasks_completed(self):
        for project in self:
            if not project.stage_id:
                continue

            stage_model = project.stage_id._name
            last_stage = self.env[stage_model].search([], order='sequence desc, id desc', limit=1)
            
            is_done_stage = project.stage_id.fold or (last_stage and project.stage_id.id == last_stage.id)
            
            if is_done_stage:
                tasks = self.env['project.task'].search([('project_id', '=', project.id)])
                
                for task in tasks:
                    is_task_done = task.state == '1_done' or (task.stage_id and task.stage_id.name and task.stage_id.name.lower() in ['done', 'completed'])
                    if not is_task_done:
                        raise ValidationError(_("You cannot move this project to the completed/last stage because there are incomplete tasks. Please complete all tasks first."))
